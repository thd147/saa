# 마크 마스터 KR v5.1 — Android 16 / One UI 8.5

**안드로이드 앱 소스 프로젝트이며, 이 ZIP 안에는 설치 가능한 APK가 없습니다.**

- 고유 앱 ID: `kr.toolbox.minemasterkr5`
- Android 16(API 36) 대상 / Java 17 / Gradle 8.13 / AGP 8.13.2
- 사용자 제공 곡괭이 앱 아이콘, 한글 명령어 버튼, 아이템 검색, 효과·마법부여·좌표 메뉴
- WebView, 네이티브 라이브러리, 저장소/네트워크/오버레이 권한 없음
- 사용자 인터페이스 오류 시 제한된 간편 메뉴로 복귀 (시스템/설치 오류에는 적용 안 됨)
- Minecraft를 직접 해킹하거나 조작하는 프로그램 아님. 게임 채팅창에 명령어를 복사해서 넣는 도구.

## 컴퓨터에서 GitHub로 APK 만들기

1. 본 ZIP을 풀고 폴더 내부 `app`, `.github`, `build.gradle.kts` 등을 GitHub 새 저장소 **최상위**에 업로드합니다.
2. Actions → **Build MineMaster KR Android 16 APK** → Run workflow 선택.
3. 초록색 빌드 성공 후 **Artifacts → MineMaster-KR-v5.1-Android16-APK** 다운로드.
4. ZIP을 풀어 `app-debug.apk`를 갤럭시 Android 16에서 설치합니다.
5. Google Play 프로텍트가 유해한 앱으로 차단하면 설치를 중단합니다.

## 휴대폰에서 ZIP만 올리는 간편 방법

1. 함께 제공된 `MineMaster_KR_v5_1_Project.zip` 파일을 GitHub 새 저장소의 루트에 업로드합니다. **파일 이름을 바꾸지 마세요.**
2. GitHub에서 `Add file → Create new file`을 누르고 파일 이름을 `.github/workflows/build.yml`로 적습니다.
3. 함께 제공된 `GitHub_Mobile_Build_Workflow.yml` 내용을 전부 복사하여 붙여넣고 Commit 합니다.
4. **Actions → Build MineMaster KR from source ZIP → Run workflow**로 실행합니다.
5. **Artifacts**에서 APK를 다운로드합니다.

## 검증 범위

- Java 정적 검사, XML 리소스, 아이콘 파일, ZIP 무결성을 확인하되 실제 Android SDK의 APK 빌드/갤럭시 설치는 이 환경에서 시험하지 못했습니다.
- 최종 빌드의 `apksigner verify` / `aapt dump badging` 단계가 통과해야만 APK artifact가 게시되도록 구성했습니다.
- APK 설치 실패 시 무조건 Play 프로텍트나 Samsung 보안을 끄지 마세요.

공식 빌드 조합 참고: https://developer.android.com/build/releases/agp-8-13-0-release-notes
GitHub Android 도구: https://github.com/android-actions/setup-android
