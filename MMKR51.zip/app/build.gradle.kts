plugins {
    id("com.android.application")
}

android {
    namespace = "kr.toolbox.minemasterkr5"
    compileSdk = 36

    defaultConfig {
        applicationId = "kr.toolbox.minemasterkr5"
        minSdk = 26
        targetSdk = 36
        versionCode = 510
        versionName = "5.1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
        debug { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
