plugins { id("com.android.application") }

android {
    namespace = "kr.toolbox.minemasterkr7"
    compileSdk = 36
    defaultConfig {
        applicationId = "kr.toolbox.minemasterkr7"
        minSdk = 26
        targetSdk = 36
        versionCode = 700
        versionName = "7.0.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
        debug { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
