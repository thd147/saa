package kr.toolbox.minemasterkr7;

import java.util.Locale;

/** Bedrock-only command generator. Never executes commands or accesses game memory. */
public final class CommandFactory {
    private CommandFactory() {}

    public static String give(String rawItem, String rawCount) {
        String item = rawItem.trim().toLowerCase(Locale.ROOT);
        if (!item.matches("(?:minecraft:)?[a-z0-9_]{1,64}")) throw new IllegalArgumentException("아이템 ID를 확인해 주세요. 영문·숫자·밑줄만 가능합니다.");
        int n = boundedInt(rawCount, 1, 64, "아이템 수량");
        return "/give @s " + item + " " + n;
    }

    public static String effect(String id, String rawSeconds, String rawLevel) {
        if (!id.matches("[a-z_]{2,40}")) throw new IllegalArgumentException("효과 ID가 올바르지 않습니다.");
        int sec = boundedInt(rawSeconds, 1, 1000000, "효과 시간");
        int level = boundedInt(rawLevel, 1, 5, "효과 단계");
        // Bedrock amplifier is zero-based: shown level 1 -> amplifier 0.
        return "/effect @s " + id + " " + sec + " " + (level - 1) + " true";
    }

    public static String enchant(String id, String rawLevel, int maxLevel) {
        if (!id.matches("[a-z_]{2,40}")) throw new IllegalArgumentException("마법부여 ID가 올바르지 않습니다.");
        int level = boundedInt(rawLevel, 1, maxLevel, "마법부여 단계");
        return "/enchant @s " + id + " " + level;
    }

    public static String tp(String x, String y, String z) {
        if (!validCoord(x) || !validCoord(y) || !validCoord(z)) throw new IllegalArgumentException("좌표는 숫자·~·~10·~-5 등으로 입력하세요.");
        return "/tp @s " + x.trim() + " " + y.trim() + " " + z.trim();
    }

    public static String summon(String id) {
        String safe = id.trim().toLowerCase(Locale.ROOT);
        if (!safe.matches("(?:minecraft:)?[a-z0-9_]{2,64}")) throw new IllegalArgumentException("몹 ID를 확인해 주세요.");
        return "/summon " + safe + " ~ ~ ~";
    }

    public static int boundedInt(String raw, int min, int max, String label) {
        try {
            int n = Integer.parseInt(raw.trim());
            if (n >= min && n <= max) return n;
        } catch (NumberFormatException ignored) { }
        throw new IllegalArgumentException(label + "은(는) " + min + "~" + max + " 사이여야 합니다.");
    }

    public static boolean validCoord(String value) {
        if (value == null) return false;
        return value.trim().matches("(?:~(?:-?\\d+(?:\\.\\d+)?)?|-?\\d+(?:\\.\\d+)?)");
    }
}
