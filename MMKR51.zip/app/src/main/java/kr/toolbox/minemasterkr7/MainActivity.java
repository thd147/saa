package kr.toolbox.minemasterkr7;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.net.Uri;
import java.io.InputStream;
import java.io.OutputStream;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * MineMaster KR 6 is an offline, native Android Bedrock command assistant.
 * It does NOT execute commands in Minecraft, require root, or inject code.
 */
public final class MainActivity extends Activity {
    private static final int EXPORT_GAME_PACK = 7011;
    private static final String PACK_ASSET = "MineMaster_KR_v7_InGame.mcpack";
    private static final int BG = Color.rgb(8, 20, 20);
    private static final int SURFACE = Color.rgb(20, 41, 40);
    private static final int SURFACE_ALT = Color.rgb(27, 53, 50);
    private static final int INNER = Color.rgb(10, 31, 30);
    private static final int ACCENT = Color.rgb(63, 225, 169);
    private static final int FORE = Color.rgb(241, 250, 247);
    private static final int MUTED = Color.rgb(169, 197, 185);
    private static final int BLUE = Color.rgb(56, 116, 160);
    private static final String[] CATS = {"전체", "아이템", "능력", "장비", "월드", "몹", "편의"};
    private static final String HOME = "home", CATALOG = "catalog", FAV = "fav", RECENT = "recent";

    private static final class Entry {
        final String category, icon, title, subtitle, cmd;
        Entry(String category, String icon, String title, String subtitle, String cmd) {
            this.category = category; this.icon = icon; this.title = title; this.subtitle = subtitle; this.cmd = cmd;
        }
        String key() { return category + "/" + title; }
    }

    private final List<Entry> catalog = new ArrayList<>();
    private final List<String> history = new ArrayList<>();
    private final Set<String> favorites = new HashSet<>();
    private SharedPreferences prefs;
    private LinearLayout body;
    private LinearLayout bottom;
    private LinearLayout catalogCards;
    private LinearLayout categoryChips;
    private EditText searchField;
    private String page = HOME;
    private String category = "전체";
    private String query = "";
    private boolean safeMode = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
            prefs = getSharedPreferences("mmkr_v7", MODE_PRIVATE);
            favorites.addAll(prefs.getStringSet("favorites", Collections.emptySet()));
            readHistory();
            fillCatalog();
            if (savedInstanceState != null) {
                page = savedInstanceState.getString("page", HOME);
                category = savedInstanceState.getString("category", "전체");
                query = savedInstanceState.getString("query", "");
            }
            createShell();
        } catch (Exception e) {
            android.util.Log.e("MineMasterKR", "UI init issue", e);
            showSafeMenu();
        }
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        out.putString("page", page); out.putString("category", category); out.putString("query", query);
        super.onSaveInstanceState(out);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int fill, int radius) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radius)); return g;
    }
    private GradientDrawable outline(int fill, int stroke, int radius) {
        GradientDrawable g = shape(fill, radius); g.setStroke(dp(1), stroke); return g;
    }
    private LinearLayout column() { LinearLayout v = new LinearLayout(this); v.setOrientation(1); return v; }
    private LinearLayout row() { LinearLayout v = new LinearLayout(this); v.setOrientation(0); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    private LinearLayout.LayoutParams lp(int w, int h, int bottom) {
        LinearLayout.LayoutParams x = new LinearLayout.LayoutParams(w, h); x.bottomMargin = dp(bottom); return x;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true); return t;
    }
    private Button action(String s, int color) {
        Button b = new Button(this); b.setText(s); b.setTextSize(13); b.setTextColor(FORE);
        b.setAllCaps(false); b.setMinHeight(dp(44)); b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setBackground(shape(color, 12)); return b;
    }
    private void section(LinearLayout dest, String title, String caption) {
        dest.addView(label(title, 19, FORE, true), lp(-1, -2, 3));
        if (caption != null) dest.addView(label(caption, 12, MUTED, false), lp(-1, -2, 13));
    }
    private ScrollView scrolling(LinearLayout wrapper) {
        ScrollView v = new ScrollView(this); v.setFillViewport(true); v.setVerticalScrollBarEnabled(false);
        v.setClipToPadding(false); v.addView(wrapper); return v;
    }

    private void createShell() {
        LinearLayout app = column(); app.setBackgroundColor(BG);
        final int h = dp(14), v = dp(10);
        app.setPadding(h, dp(30), h, dp(12));
        if (Build.VERSION.SDK_INT >= 30) {
            app.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(h, i.top + v, h, i.bottom + v);
                return insets;
            });
        }
        setContentView(app);

        LinearLayout top = row(); top.setPadding(dp(1), dp(5), dp(1), dp(12));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher); logo.setContentDescription("곡괭이 앱 아이콘");
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        top.addView(logo, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout titles = column(); titles.setPadding(dp(11), 0, 0, 0);
        titles.addView(label("마크 마스터 KR", 22, FORE, true));
        titles.addView(label("V7.0  •  BEDROCK  •  IN-GAME + OFFLINE", 11, ACCENT, true));
        top.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        Button help = action("?", SURFACE_ALT); help.setContentDescription("앱 사용법");
        help.setOnClickListener(view -> showHelp());
        top.addView(help, new LinearLayout.LayoutParams(dp(44), dp(44)));
        app.addView(top);
        body = column();
        app.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        bottom = row(); bottom.setGravity(Gravity.CENTER); bottom.setPadding(0, dp(9), 0, 0);
        app.addView(bottom, new LinearLayout.LayoutParams(-1, dp(66)));
        renderBottom(); renderPage();
    }

    private void navigate(String to) {
        page = to; query = ""; searchField = null;
        hideKeyboard(); renderBottom(); renderPage();
    }
    private void renderBottom() {
        if (bottom == null) return;
        bottom.removeAllViews();
        String[] names = {"⌂ 홈", "▤ 도구", "☆ 즐겨찾기", "↺ 최근"};
        String[] pages = {HOME, CATALOG, FAV, RECENT};
        for (int i=0; i<names.length; i++) {
            final String go = pages[i];
            Button button = action(names[i], page.equals(go) ? Color.rgb(35, 129, 101) : SURFACE);
            button.setTextSize(11);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1);
            if (i > 0) p.leftMargin = dp(6);
            button.setOnClickListener(view -> navigate(go));
            bottom.addView(button, p);
        }
    }
    private void renderPage() {
        if (body == null) return;
        body.removeAllViews();
        if (HOME.equals(page)) renderHome();
        else if (CATALOG.equals(page)) renderCatalog();
        else if (FAV.equals(page)) renderFavorites();
        else if (RECENT.equals(page)) renderRecent();
    }

    private void renderHome() {
        LinearLayout content = column(); content.setPadding(dp(2), 0, dp(2), dp(18));
        body.addView(scrolling(content), new LinearLayout.LayoutParams(-1, -1));
        LinearLayout hero = column(); hero.setPadding(dp(18), dp(18), dp(18), dp(16));
        hero.setBackground(outline(Color.rgb(17, 57, 45), Color.rgb(40, 112, 80), 20));
        hero.addView(label("⚡ 마크 PE 치트 도우미", 21, FORE, true), lp(-1,-2,5));
        hero.addView(label("게임팩을 설치하면 게임 안에서 원터치 적용 · 앱 자체도 명령어 복사 지원", 12, MUTED, false), lp(-1,-2,12));
        LinearLayout controls = row();
        Button m = action("▶ 마크 실행", Color.rgb(32, 120, 86));
        m.setOnClickListener(view -> launchMinecraft());
        controls.addView(m, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button builder = action("＋ 직접 만들기", BLUE);
        builder.setOnClickListener(view -> openBuilder());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1); p.leftMargin=dp(8);
        controls.addView(builder, p); hero.addView(controls);
        Button addon = action("🎮 게임 내 한글 메뉴 설치팩 저장", Color.rgb(21, 137, 107));
        addon.setOnClickListener(v -> exportGamePack());
        hero.addView(addon, lp(-1, dp(52), 7));
        TextView gameHint = label("설치팩 저장 → 파일 관리자에서 Minecraft로 가져오기 → 월드 행동 팩 활성화 → 게임 안에서 아이템을 터치하면 즉시 적용", 12, MUTED, false);
        hero.addView(gameHint, lp(-1, -2, 8));
        content.addView(hero, lp(-1,-2,18));

        section(content, "빠른 실행", "앱에선 명령어 복사 · 게임팩에선 게임 안에서 즉시 적용");
        addQuickRow(content, "💎 다이아 ×64", "/give @s diamond 64", "👁 야간 투시", "/effect @s night_vision 3600 0 true");
        addQuickRow(content, "⚡ 이동 속도", "/effect @s speed 3600 2 true", "🛡 방어 강화", "/effect @s resistance 3600 3 true");
        addQuickRow(content, "🌤 맑은 날씨", "/weather clear", "🧹 효과 제거", "/effect @s clear");

        section(content, "기능 둘러보기", "카테고리를 선택하면 해당 도구로 이동합니다");
        addCategoryRow(content, "💎 아이템", "아이템", "⚡ 치트 능력", "능력");
        addCategoryRow(content, "⚔ 장비 강화", "장비", "🌎 월드 설정", "월드");
        addCategoryRow(content, "🐺 몹 소환", "몹", "🛠 편의", "편의");
        if (!history.isEmpty()) {
            section(content,"최근 사용","최근 복사한 명령어 다시 사용");
            TextView last = label(history.get(0), 12, ACCENT, false);
            last.setPadding(dp(14), dp(14), dp(14), dp(14)); last.setBackground(shape(SURFACE, 13));
            last.setOnClickListener(view -> copyCommand(history.get(0)));
            content.addView(last, lp(-1,-2,12));
        }
        TextView warning = label("ⓘ 이 앱은 게임 메모리를 수정하거나 서버 보호를 우회하지 않습니다. 명령어는 치트 허용 월드/운영자 권한에서만 작동합니다.", 12, MUTED, false);
        warning.setPadding(dp(7), dp(12), dp(7), dp(18)); content.addView(warning);
    }
    private void addQuickRow(LinearLayout parent, String a, String ca, String b, String cb) {
        LinearLayout r = row();
        quickButton(r,a,ca,true); quickButton(r,b,cb,false);
        parent.addView(r, lp(-1, dp(58), 8));
    }
    private void quickButton(LinearLayout row, String title, String cmd, boolean first) {
        Button b=action(title,SURFACE); b.setOnClickListener(v -> copyCommand(cmd));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,-1,1); if(!first)p.leftMargin=dp(8); row.addView(b,p);
    }
    private void addCategoryRow(LinearLayout parent, String a, String catA, String b, String catB) {
        LinearLayout r = row(); categoryButton(r,a,catA,true); categoryButton(r,b,catB,false);
        parent.addView(r, lp(-1,dp(54),8));
    }
    private void categoryButton(LinearLayout r,String title,String cat,boolean first) {
        Button b=action(title,SURFACE_ALT);
        b.setOnClickListener(v -> {category=cat;navigate(CATALOG);});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);if(!first)p.leftMargin=dp(8);r.addView(b,p);
    }

    private void renderCatalog() {
        LinearLayout frame = column(); body.addView(frame, new LinearLayout.LayoutParams(-1,-1));
        TextView head=label("도구 모음  ·  " + catalog.size() + "개", 19, FORE, true);
        frame.addView(head, lp(-1,-2,8));
        searchField=new EditText(this); searchField.setSingleLine(true); searchField.setTextSize(14);
        searchField.setTextColor(FORE);searchField.setHintTextColor(MUTED);
        searchField.setHint("아이템·치트·명령어 검색"); searchField.setBackground(shape(SURFACE,12));
        searchField.setPadding(dp(14), dp(8),dp(14),dp(8));
        searchField.setText(query); searchField.setSelection(query.length());
        frame.addView(searchField, lp(-1,dp(48),10));
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
        categoryChips=row();hs.addView(categoryChips);frame.addView(hs,lp(-1,dp(46),8));
        renderChips();
        ScrollView listScroll = new ScrollView(this);listScroll.setFillViewport(true);listScroll.setVerticalScrollBarEnabled(false);
        catalogCards=column();catalogCards.setPadding(0,dp(2),0,dp(20));listScroll.addView(catalogCards);
        frame.addView(listScroll,new LinearLayout.LayoutParams(-1,0,1));
        searchField.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int co,int af){}
            public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();renderCatalogCards();}
            public void afterTextChanged(Editable e){}
        });
        renderCatalogCards();
    }
    private void renderChips() {
        if(categoryChips==null)return;
        categoryChips.removeAllViews();
        for(String name:CATS){
            Button b=action(name,name.equals(category)?Color.rgb(31,132,100):SURFACE);
            b.setTextSize(12); b.setOnClickListener(v->{category=name;renderChips();renderCatalogCards();});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(40));p.rightMargin=dp(7);
            categoryChips.addView(b,p);
        }
    }
    private void renderCatalogCards() {
        if(catalogCards==null) return;
        catalogCards.removeAllViews();
        String needle=query.trim().toLowerCase(Locale.ROOT);
        int total=0;
        for (Entry e: catalog) {
            if(!category.equals("전체") && !e.category.equals(category))continue;
            if(!(e.title+" "+e.subtitle+" "+e.cmd).toLowerCase(Locale.ROOT).contains(needle))continue;
            catalogCards.addView(entryCard(e),lp(-1,-2,9)); total++;
        }
        if(total==0) empty(catalogCards,"검색 결과가 없습니다. 다른 단어로 검색하거나 직접 명령어를 만들어 보세요.");
    }
    private LinearLayout entryCard(Entry e) {
        LinearLayout card=column();card.setPadding(dp(14),dp(12),dp(14),dp(13));card.setBackground(shape(SURFACE,15));
        LinearLayout top=row();
        LinearLayout info=column();
        info.addView(label(e.icon+" "+e.title,16,FORE,true),lp(-1,-2,3));
        info.addView(label(e.subtitle,12,MUTED,false));
        top.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        Button star=action(favorites.contains(e.key())?"★":"☆",SURFACE_ALT);
        star.setTextColor(favorites.contains(e.key())?ACCENT:FORE);
        star.setContentDescription(favorites.contains(e.key())?"즐겨찾기 해제":"즐겨찾기에 추가");
        star.setOnClickListener(v->{toggleFavorite(e);star.setText(favorites.contains(e.key())?"★":"☆");star.setTextColor(favorites.contains(e.key())?ACCENT:FORE);});
        top.addView(star,new LinearLayout.LayoutParams(dp(46),dp(40)));
        card.addView(top,lp(-1,-2,10));
        TextView command=label(e.cmd,12,ACCENT,false);command.setBackground(shape(INNER,9));
        command.setPadding(dp(10),dp(10),dp(10),dp(10));command.setTextIsSelectable(true);
        card.addView(command,lp(-1,-2,10));
        Button copy=action("명령어 복사  ⧉",Color.rgb(31,121,91));
        copy.setOnClickListener(v->copyCommand(e.cmd));card.addView(copy,new LinearLayout.LayoutParams(-1,dp(45)));
        return card;
    }
    private void empty(LinearLayout parent,String value) {
        TextView txt=label(value,14,MUTED,false);txt.setPadding(dp(14),dp(28),dp(14),dp(20));parent.addView(txt);
    }
    private void renderFavorites() {
        LinearLayout c=column();body.addView(scrolling(c),new LinearLayout.LayoutParams(-1,-1));
        section(c,"★ 즐겨찾기", "자주 쓰는 도구를 저장하고 바로 복사할 수 있어요");
        int count=0;
        for(Entry e:catalog){if(favorites.contains(e.key())){c.addView(entryCard(e),lp(-1,-2,10));count++;}}
        if(count==0)empty(c,"저장된 즐겨찾기가 없어요. 도구 목록에서 ☆를 누르면 여기에 표시됩니다.");
        Button go=action("전체 도구 보러 가기",SURFACE_ALT);
        go.setOnClickListener(v->navigate(CATALOG));c.addView(go,lp(-1,dp(52),12));
    }
    private void renderRecent() {
        LinearLayout c=column();body.addView(scrolling(c),new LinearLayout.LayoutParams(-1,-1));
        section(c,"↺ 최근 복사한 명령어", "최대 20개 · 기기에만 저장됩니다");
        if(history.isEmpty()) empty(c,"아직 사용한 명령어가 없습니다.");
        for(String cmd:new ArrayList<>(history)){
            LinearLayout card=column();card.setPadding(dp(13),dp(13),dp(13),dp(13));card.setBackground(shape(SURFACE,13));
            TextView preview=label(cmd,13,ACCENT,false);preview.setTextIsSelectable(true);card.addView(preview,lp(-1,-2,8));
            Button reuse=action("다시 복사",Color.rgb(31,121,91));reuse.setOnClickListener(v->copyCommand(cmd));
            card.addView(reuse,new LinearLayout.LayoutParams(-1,dp(43)));c.addView(card,lp(-1,-2,10));
        }
        if(!history.isEmpty()){
            Button clear=action("최근 기록 삭제",SURFACE_ALT);
            clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("최근 기록 삭제")
                .setMessage("복사 기록을 모두 지울까요?").setPositiveButton("삭제",(d,w)->{history.clear();saveHistory();renderPage();})
                .setNegativeButton("취소",null).show());
            c.addView(clear,lp(-1,dp(49),13));
        }
    }

    private void readHistory() {
        history.clear();
        try {
            JSONArray arr=new JSONArray(prefs.getString("history","[]"));
            for(int i=0;i<arr.length()&&history.size()<20;i++){
                String s=arr.optString(i,"");if(s.startsWith("/")&&s.length()<300)history.add(s);
            }
        }catch(Exception e){prefs.edit().remove("history").apply();}
    }
    private void saveHistory() {
        JSONArray a=new JSONArray();for(String c:history)a.put(c);
        prefs.edit().putString("history",a.toString()).apply();
    }
    private void toggleFavorite(Entry e) {
        if(!favorites.add(e.key()))favorites.remove(e.key());
        prefs.edit().putStringSet("favorites",new HashSet<>(favorites)).apply();
        if(FAV.equals(page))renderPage();
        else Toast.makeText(this,favorites.contains(e.key())?"즐겨찾기에 추가했어요":"즐겨찾기를 해제했어요",Toast.LENGTH_SHORT).show();
    }
    private void copyCommand(String command) {
        try {
            ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(clipboard==null)throw new IllegalStateException("Clipboard unavailable");
            clipboard.setPrimaryClip(ClipData.newPlainText("Bedrock command",command));
            history.remove(command);history.add(0,command);
            while(history.size()>20)history.remove(history.size()-1);
            saveHistory();
            Toast.makeText(this,"복사 완료 · 마크 채팅창에 붙여넣으세요",Toast.LENGTH_SHORT).show();
            if(RECENT.equals(page))renderPage();
        } catch(Exception e){
            new AlertDialog.Builder(this).setTitle("명령어").setMessage(command)
                    .setPositiveButton("확인",null).show();
        }
    }
    private void launchMinecraft() {
        try {
            Intent intent=getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
            if(intent==null){Toast.makeText(this,"Minecraft 앱을 찾을 수 없어요. 직접 열어주세요.",Toast.LENGTH_LONG).show();return;}
            startActivity(intent);
        }catch(Exception e){Toast.makeText(this,"마크 실행 실패 · 홈 화면에서 직접 실행해 주세요",Toast.LENGTH_LONG).show();}
    }
    private void exportGamePack() {
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/octet-stream");
            intent.putExtra(Intent.EXTRA_TITLE, PACK_ASSET);
            startActivityForResult(intent, EXPORT_GAME_PACK);
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("설치팩 저장 실패")
                .setMessage("시스템 파일 저장 화면을 열 수 없습니다. 앱 외부에서 .mcpack 파일을 직접 다운로드하는 방법을 이용하세요.")
                .setPositiveButton("확인", null).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_GAME_PACK || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri target = data.getData();
        try (InputStream in = getAssets().open(PACK_ASSET);
             OutputStream out = getContentResolver().openOutputStream(target, "w")) {
            if (out == null) throw new IllegalStateException("출력 파일을 열 수 없습니다.");
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.flush();
            new AlertDialog.Builder(this).setTitle("🎮 게임용 팩 저장 완료")
                .setMessage("1. 내 파일에서 .mcpack을 Minecraft로 여세요.\n2. 마인크래프트 월드 설정 → 행동 팩 → 마크 마스터 KR 7.0 활성화\n3. 새 테스트 월드에 입장하면 메뉴 아이템을 받습니다.\n4. 손에 들고 [사용]을 누르세요.\n\n※ 앱 자체만 설치해서는 게임에 자동 적용되지 않습니다.\n※ Minecraft가 파일 연결 목록에 안 보이면 파일 관리자/PC로 가져오기를 해야 할 수 있습니다.")
                .setPositiveButton("확인", null).show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("저장 실패")
                .setMessage(e.getMessage()).setPositiveButton("확인", null).show();
        }
    }

    private void hideKeyboard(){
        try{View focus=getCurrentFocus();if(focus!=null){InputMethodManager m=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(m!=null)m.hideSoftInputFromWindow(focus.getWindowToken(),0);focus.clearFocus();}}catch(Exception ignored){}
    }
    private void showHelp() {
        new AlertDialog.Builder(this).setTitle("마크 마스터 KR 7.0 사용법")
            .setMessage("① 홈의 [게임 내 한글 메뉴 설치팩 저장]을 눌러 .mcpack 파일을 저장하세요.\n② 파일 관리자에서 Minecraft로 가져오세요.\n③ 월드 행동 팩을 활성화한 다음, 게임 안 메뉴 아이템을 눌러 아이템/효과/인챈트를 즉시 적용할 수 있습니다.\n\n외부 앱의 명령어 도감과 즐겨찾기는 오프라인에서도 작동합니다.\n\n이 앱은 게임 메모리를 후킹하거나 서버 보호를 우회하지 않습니다.")
            .setPositiveButton("확인",null).show();
    }
    private void showSafeMenu() {
        safeMode=true;
        LinearLayout c=column();c.setBackgroundColor(BG);c.setPadding(dp(20),dp(48),dp(20),dp(16));
        c.addView(label("마크 마스터 KR 7 · 간편 모드",22,FORE,true),lp(-1,-2,13));
        c.addView(label("화면 오류가 발생해 간편 메뉴로 열었습니다.",13,MUTED,false),lp(-1,-2,13));
        final String[] labels={"💎 다이아몬드 64개","⚡ 속도 강화","👁 야간 투시","🌤 낮으로","▶ 마크 열기"};
        final String[] commands={"/give @s diamond 64","/effect @s speed 3600 2 true","/effect @s night_vision 3600 0 true","/time set day"};
        for(int i=0;i<labels.length;i++){
            final int j=i;Button b=action(labels[i],SURFACE_ALT);
            b.setOnClickListener(v->{if(j==4)launchMinecraft();else copyCommand(commands[j]);});
            c.addView(b,lp(-1,dp(50),10));
        }
        setContentView(c);
    }

    // Command builders deliberately validate user input before generating commands.
    private EditText field(String hint,String initial,boolean number) {
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(initial);
        e.setTextSize(16);e.setSelectAllOnFocus(true);
        if(number)e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        return e;
    }
    private LinearLayout dialogBody(){LinearLayout c=column();c.setPadding(dp(20),dp(9),dp(20),dp(5));return c;}
    private void showError(Exception e){new AlertDialog.Builder(this).setTitle("입력을 확인해주세요").setMessage(e.getMessage()).setPositiveButton("확인",null).show();}
    private void openBuilder() {
        String[] names={"💎 아이템 지급", "⚡ 상태 효과", "⚔ 마법부여", "📍 좌표 이동", "🐺 몹 소환"};
        new AlertDialog.Builder(this).setTitle("내 명령어 만들기")
            .setItems(names,(d,index)->{
                switch(index){case 0:buildItem();break;case 1:buildEffect();break;case 2:buildEnchant();break;case 3:buildTp();break;default:buildSummon();}
            }).setNegativeButton("취소",null).show();
    }
    private void buildItem() {
        LinearLayout c=dialogBody();EditText id=field("아이템 영문 ID","diamond",false);EditText amount=field("수량","64",true);
        c.addView(id);c.addView(amount);
        new AlertDialog.Builder(this).setTitle("아이템 지급").setView(c)
            .setPositiveButton("복사",(d,w)->{try{copyCommand(CommandFactory.give(id.getText().toString(),amount.getText().toString()));}catch(Exception e){showError(e);}})
            .setNegativeButton("취소",null).show();
    }
    private static final String[] EFFECT_LABELS={"속도","점프 강화","힘","저항","야간 투시","성급함","화염 저항","재생","수중 호흡","투명화","느린 낙하"};
    private static final String[] EFFECT_IDS={"speed","jump_boost","strength","resistance","night_vision","haste","fire_resistance","regeneration","water_breathing","invisibility","slow_falling"};
    private void buildEffect() {
        LinearLayout c=dialogBody();Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,EFFECT_LABELS));c.addView(s);
        EditText sec=field("시간(초)","3600",true);EditText lvl=field("효과 단계 1~5","2",true);c.addView(sec);c.addView(lvl);
        new AlertDialog.Builder(this).setTitle("상태 효과").setView(c)
            .setPositiveButton("복사",(d,w)->{try{copyCommand(CommandFactory.effect(EFFECT_IDS[s.getSelectedItemPosition()],sec.getText().toString(),lvl.getText().toString()));}catch(Exception e){showError(e);}})
            .setNegativeButton("취소",null).show();
    }
    private static final String[] ENCHANT_LABELS={"날카로움 (최대 V)","효율 (최대 V)","내구성 (최대 III)","수선 (최대 I)","보호 (최대 IV)","행운 (최대 III)","약탈 (최대 III)","발화 (최대 II)","가벼운 착지 (최대 IV)","호흡 (최대 III)","밀치기 (최대 II)"};
    private static final String[] ENCHANT_IDS={"sharpness","efficiency","unbreaking","mending","protection","fortune","looting","fire_aspect","feather_falling","respiration","knockback"};
    private static final int[] ENCHANT_MAX={5,5,3,1,4,3,3,2,4,3,2};
    private void buildEnchant(){
        LinearLayout c=dialogBody();Spinner spinner=new Spinner(this);spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ENCHANT_LABELS));c.addView(spinner);
        EditText level=field("단계", "1", true);c.addView(level);
        c.addView(label("마인크래프트에서 강화할 장비를 손에 들고 사용하세요.",12,Color.DKGRAY,false));
        new AlertDialog.Builder(this).setTitle("마법부여").setView(c)
            .setPositiveButton("복사",(d,w)->{try{int pos=spinner.getSelectedItemPosition();copyCommand(CommandFactory.enchant(ENCHANT_IDS[pos],level.getText().toString(),ENCHANT_MAX[pos]));}catch(Exception e){showError(e);}})
            .setNegativeButton("취소",null).show();
    }
    private void buildTp(){
        LinearLayout c=dialogBody();EditText x=field("X","~",false),y=field("Y","~",false),z=field("Z","~",false);
        c.addView(x);c.addView(y);c.addView(z);
        new AlertDialog.Builder(this).setTitle("좌표 이동").setView(c)
            .setPositiveButton("복사",(d,w)->{try{copyCommand(CommandFactory.tp(x.getText().toString(),y.getText().toString(),z.getText().toString()));}catch(Exception e){showError(e);}})
            .setNegativeButton("취소",null).show();
    }
    private void buildSummon(){
        String[] labels={"소", "양", "늑대", "고양이", "말", "주민", "좀비", "스켈레톤", "크리퍼", "아이언 골렘"};
        String[] ids={"cow","sheep","wolf","cat","horse","villager","zombie","skeleton","creeper","iron_golem"};
        new AlertDialog.Builder(this).setTitle("몹 소환")
            .setItems(labels,(d,index)->copyCommand(CommandFactory.summon(ids[index])))
            .setNegativeButton("취소",null).show();
    }

    private void add(String cat,String icon,String title,String desc,String cmd) {catalog.add(new Entry(cat,icon,title,desc,cmd));}
    private void fillCatalog() {
        // Curated Bedrock commands, not Java Edition give/NBT syntax.
        add("아이템","💎","다이아몬드 ×64","광물 재료", "/give @s diamond 64");
        add("아이템","🟩","에메랄드 ×64","주민 거래", "/give @s emerald 64");
        add("아이템","🪙","금괴 ×64","금 재료", "/give @s gold_ingot 64");
        add("아이템","🔩","철괴 ×64","철 재료", "/give @s iron_ingot 64");
        add("아이템","🟫","네더라이트 주괴 ×16","최종 장비 제작", "/give @s netherite_ingot 16");
        add("아이템","⚔","네더라이트 검","최종 전투 무기", "/give @s netherite_sword 1");
        add("아이템","⛏","네더라이트 곡괭이","최종 채굴 도구", "/give @s netherite_pickaxe 1");
        add("아이템","🪓","네더라이트 도끼","나무 채집 및 전투", "/give @s netherite_axe 1");
        add("아이템","🛡","방패","방어용 장비", "/give @s shield 1");
        add("아이템","👑","네더라이트 투구","고급 방어구", "/give @s netherite_helmet 1");
        add("아이템","🎽","네더라이트 흉갑","고급 방어구", "/give @s netherite_chestplate 1");
        add("아이템","👖","네더라이트 레깅스","고급 방어구", "/give @s netherite_leggings 1");
        add("아이템","🥾","네더라이트 부츠","고급 방어구", "/give @s netherite_boots 1");
        add("아이템","🍎","마법 황금사과 ×4","희귀 식량", "/give @s enchanted_golden_apple 4");
        add("아이템","🍞","빵 ×64","탐험 식량", "/give @s bread 64");
        add("아이템","🥩","구운 소고기 ×64","생존 식량", "/give @s cooked_beef 64");
        add("아이템","🪣","물 양동이","낙하·건축용", "/give @s water_bucket 1");
        add("아이템","✨","경험치 병 ×64","경험치 획득", "/give @s experience_bottle 64");
        add("아이템","📦","셜커 상자","휴대용 보관 상자", "/give @s shulker_box 1");
        add("아이템","🧰","엔더 상자","공유형 개인 보관", "/give @s ender_chest 1");
        add("아이템","🏮","횃불 ×64","동굴 탐험", "/give @s torch 64");
        add("아이템","🪵","참나무 원목 ×64","건축 재료", "/give @s oak_log 64");
        add("아이템","🧱","돌 ×64","건축 블록", "/give @s stone 64");
        add("아이템","🧪","양조기","물약 만들기", "/give @s brewing_stand 1");
        add("아이템","🪽","겉날개","하늘 활공", "/give @s elytra 1");
        add("아이템","🚀","폭죽 로켓 ×64","겉날개 비행 도움", "/give @s firework_rocket 64");
        add("아이템","🔱","삼지창","수중 무기", "/give @s trident 1");
        add("아이템","🏹","활과 화살","활 지급", "/give @s bow 1");
        add("아이템","🏹","화살 ×64","탄약 지급", "/give @s arrow 64");
        add("아이템","🪄","명령 블록","치트 허용 월드에서 사용", "/give @s command_block 1");
        add("능력","⚡","달리기 속도 III","1시간 · 속도", "/effect @s speed 3600 2 true");
        add("능력","🦘","슈퍼 점프 III","1시간 · 점프 강화", "/effect @s jump_boost 3600 2 true");
        add("능력","💪","힘 IV","1시간 · 근접 공격", "/effect @s strength 3600 3 true");
        add("능력","🛡","저항 IV","1시간 · 피해 감소", "/effect @s resistance 3600 3 true");
        add("능력","👁","야간 투시","1시간 · 어둠에서 시야 개선", "/effect @s night_vision 3600 0 true");
        add("능력","⛏","채굴 가속 IV","1시간 · 성급함", "/effect @s haste 3600 3 true");
        add("능력","🔥","화염 저항","1시간 · 불 피해 대비", "/effect @s fire_resistance 3600 0 true");
        add("능력","❤️","재생 II","1시간 · 체력 회복", "/effect @s regeneration 3600 1 true");
        add("능력","🫧","수중 호흡","1시간 · 잠수 도움", "/effect @s water_breathing 3600 0 true");
        add("능력","🫥","투명화","1시간 · 투명화", "/effect @s invisibility 3600 0 true");
        add("능력","🪂","느린 낙하","1시간 · 낙하 속도 감소", "/effect @s slow_falling 3600 0 true");
        add("능력","💗","체력 증가 II","일시적 최대 체력 효과", "/effect @s health_boost 3600 1 true");
        add("능력","🧹","효과 전체 제거","모든 상태 효과 해제", "/effect @s clear");
        add("장비","⚔","날카로움 V","무기를 손에 들고 실행", "/enchant @s sharpness 5");
        add("장비","⛏","효율 V","도구를 손에 들고 실행", "/enchant @s efficiency 5");
        add("장비","🛡","보호 IV","방어구를 손에 들고 실행", "/enchant @s protection 4");
        add("장비","🔧","내구성 III","장비 내구도 절약", "/enchant @s unbreaking 3");
        add("장비","✨","수선 I","경험치로 장비 수리", "/enchant @s mending 1");
        add("장비","🍀","행운 III","일부 광물 드롭 증가", "/enchant @s fortune 3");
        add("장비","🎁","약탈 III","몹 드롭 증가", "/enchant @s looting 3");
        add("장비","🔥","발화 II","무기 불꽃 효과", "/enchant @s fire_aspect 2");
        add("장비","🪶","가벼운 착지 IV","부츠 낙하 피해 감소", "/enchant @s feather_falling 4");
        add("장비","🐠","호흡 III","투구 수중 호흡", "/enchant @s respiration 3");
        add("장비","💢","밀치기 II","검 밀치기 증가", "/enchant @s knockback 2");
        add("장비","🧲","끌어당기기 III","낚싯대 마법부여", "/enchant @s lure 3");
        add("장비","🏹","힘 V","활 공격력 강화", "/enchant @s power 5");
        add("장비","🏹","무한 I","활 탄약 절약", "/enchant @s infinity 1");
        add("월드","☀","낮으로 변경","게임 시간을 낮으로", "/time set day");
        add("월드","🌙","밤으로 변경","게임 시간을 밤으로", "/time set night");
        add("월드","🌅","일출","게임 시간을 일출로", "/time set sunrise");
        add("월드","🌦","맑은 날씨","비/천둥 제거", "/weather clear");
        add("월드","🌧","비 내리기","날씨를 비로", "/weather rain");
        add("월드","⚡","천둥 날씨","천둥·번개", "/weather thunder");
        add("월드","🎨","크리에이티브","게임 모드 변경", "/gamemode creative @s");
        add("월드","🌲","서바이벌","게임 모드 변경", "/gamemode survival @s");
        add("월드","👁","관전 모드","게임 모드 변경", "/gamemode spectator @s");
        add("월드","📦","아이템 유지 켜기","사망 시 아이템 보존", "/gamerule keepinventory true");
        add("월드","📦","아이템 유지 끄기","기본 규칙으로 복귀", "/gamerule keepinventory false");
        add("월드","🔄","일광 주기 켜기","낮밤 자동 변경", "/gamerule dodaylightcycle true");
        add("월드","🛑","일광 주기 끄기","낮밤 정지", "/gamerule dodaylightcycle false");
        add("월드","🌧","날씨 주기 켜기","날씨 자동 변화", "/gamerule doweathercycle true");
        add("월드","🛑","날씨 주기 끄기","날씨 고정", "/gamerule doweathercycle false");
        add("몹","🐄","소 소환","플레이어 위치", "/summon cow ~ ~ ~");
        add("몹","🐑","양 소환","플레이어 위치", "/summon sheep ~ ~ ~");
        add("몹","🐺","늑대 소환","플레이어 위치", "/summon wolf ~ ~ ~");
        add("몹","🐈","고양이 소환","플레이어 위치", "/summon cat ~ ~ ~");
        add("몹","🐎","말 소환","플레이어 위치", "/summon horse ~ ~ ~");
        add("몹","👨","주민 소환","플레이어 위치", "/summon villager ~ ~ ~");
        add("몹","🧟","좀비 소환","플레이어 위치", "/summon zombie ~ ~ ~");
        add("몹","🏹","스켈레톤 소환","플레이어 위치", "/summon skeleton ~ ~ ~");
        add("몹","💥","크리퍼 소환","플레이어 위치", "/summon creeper ~ ~ ~");
        add("몹","🤖","철 골렘 소환","플레이어 위치", "/summon iron_golem ~ ~ ~");
        add("편의","📍","현재 좌표 이동","현 위치로 이동하는 예시", "/tp @s ~ ~ ~");
        add("편의","⬆","10블록 위로 이동","수직 순간이동", "/tp @s ~ ~10 ~");
        add("편의","✨","경험치 100 지급","경험치 포인트", "/xp 100 @s");
        add("편의","🌐","좌표 보기 켜기","좌표 표시 월드 규칙", "/gamerule showcoordinates true");
        add("편의","🔇","명령 출력 끄기","채팅 출력 간소화", "/gamerule commandblockoutput false");
    }
}
