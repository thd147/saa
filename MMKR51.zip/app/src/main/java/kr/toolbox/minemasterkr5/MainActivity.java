package kr.toolbox.minemasterkr5;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Minecraft Bedrock command helper. It is intentionally native Java-only:
 * no WebView, injected code, overlays, network, storage or sensitive permissions.
 * Commands are only copied to the clipboard. The player pastes them inside a
 * Minecraft world with cheats/operator permission enabled.
 */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 23, 21);
    private static final int PANEL = Color.rgb(19, 44, 39);
    private static final int ACCENT = Color.rgb(52, 210, 158);
    private static final int FORE = Color.rgb(242, 252, 248);
    private static final int MUTED = Color.rgb(170, 197, 189);
    private static final String[] CATEGORIES = {"전체", "아이템", "치트 능력", "마법부여", "월드", "몹"};

    private static final class Entry {
        final String category, name, description, command;
        Entry(String category, String name, String description, String command) {
            this.category = category;
            this.name = name;
            this.description = description;
            this.command = command;
        }
    }

    private final List<Entry> entries = new ArrayList<>();
    private LinearLayout entriesHost;
    private LinearLayout categoriesHost;
    private TextView lastCommand;
    private EditText search;
    private String category = "전체";
    private String lastCopied = "";

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        try {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
            getWindow().getDecorView().setSystemUiVisibility(0);
            setupEntries();
            lastCopied = getPreferences(MODE_PRIVATE).getString("last_command", "");
            renderApplication();
        } catch (RuntimeException error) {
            android.util.Log.e("MineMasterKR", "Normal UI initialization failed", error);
            renderSafeMode();
        }
    }

    /** Fallback for UI errors; does not prevent system-level install or loading failures. */
    private void renderSafeMode() {
        LinearLayout root = column();
        root.setPadding(dp(20), dp(48), dp(20), dp(20));
        root.setBackgroundColor(BG);
        TextView title = text("마크 마스터 KR · 간편 모드", 22, FORE, true);
        root.addView(title, margins(-1, -2, 14));
        root.addView(text("일반 메뉴를 불러올 수 없어 안전 메뉴로 열었습니다.", 14, MUTED, false), margins(-1, -2, 14));
        String[] labels = {"💎 다이아몬드 64개", "👁 야간 투시", "🌤 낮으로", "▶ 마인크래프트 열기"};
        String[] commands = {"/give @s diamond 64", "/effect @s night_vision 3600 0 true", "/time set day"};
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            Button option = button(labels[i], PANEL);
            option.setOnClickListener(v -> {
                if (index == 3) openMinecraft();
                else copy(commands[index]);
            });
            root.addView(option, margins(-1, dp(52), 12));
        }
        setContentView(root);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private LinearLayout column() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private LinearLayout row() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private LinearLayout.LayoutParams margins(int width, int height, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private Button button(String title, int backgroundColor) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(14);
        b.setTextColor(FORE);
        b.setAllCaps(false);
        b.setBackground(rounded(backgroundColor, 13));
        b.setMinHeight(dp(46));
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        return b;
    }

    private void renderApplication() {
        LinearLayout shell = column();
        shell.setBackgroundColor(BG);
        // Android 16 enforces edge-to-edge. Respect physical system bar insets.
        int horizontal = dp(14), vertical = dp(12);
        shell.setPadding(horizontal, dp(30), horizontal, dp(22));
        if (Build.VERSION.SDK_INT >= 30) {
            shell.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(horizontal, safe.top + vertical, horizontal, safe.bottom + vertical);
                return insets;
            });
        }
        setContentView(shell);

        LinearLayout header = row();
        header.setPadding(dp(1), dp(2), dp(1), dp(10));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        header.addView(logo, new LinearLayout.LayoutParams(dp(62), dp(62)));
        LinearLayout headings = column();
        headings.setPadding(dp(9), 0, 0, 0);
        headings.addView(text("마크 마스터 KR", 23, FORE, true));
        headings.addView(text("v5.1 · Android 16 · 오프라인", 12, ACCENT, false));
        header.addView(headings, new LinearLayout.LayoutParams(0, -2, 1));
        shell.addView(header);

        TextView hint = text("마크 PE 아이템·효과·마법부여 명령어를 터치 한 번으로 복사하세요.\n※ 게임 치트가 허용된 내 월드/운영자 권한에서만 실행됩니다.", 12, MUTED, false);
        hint.setLineSpacing(dp(3), 1f);
        shell.addView(hint, margins(-1, -2, 12));

        LinearLayout actions = row();
        Button minecraft = button("▶ 마크 열기", Color.rgb(33, 102, 82));
        minecraft.setOnClickListener(v -> openMinecraft());
        actions.addView(minecraft, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button item = button("＋ 명령어 만들기", Color.rgb(32, 81, 117));
        item.setOnClickListener(v -> openBuilderMenu());
        LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(0, dp(48), 1);
        itemParams.leftMargin = dp(8);
        actions.addView(item, itemParams);
        shell.addView(actions, margins(-1, -2, 12));

        lastCommand = text("", 12, ACCENT, false);
        lastCommand.setPadding(dp(10), dp(10), dp(10), dp(10));
        lastCommand.setBackground(rounded(PANEL, 12));
        lastCommand.setOnClickListener(v -> { if (!lastCopied.isEmpty()) copy(lastCopied); });
        updateLastCommand();
        shell.addView(lastCommand, margins(-1, -2, 12));

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setTextColor(FORE);
        search.setHintTextColor(MUTED);
        search.setHint("🔎 아이템·치트 검색");
        search.setPadding(dp(14), dp(10), dp(14), dp(10));
        search.setBackground(rounded(PANEL, 13));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderEntries(); }
            @Override public void afterTextChanged(Editable e) { }
        });
        shell.addView(search, margins(-1, dp(50), 9));

        HorizontalScrollView bar = new HorizontalScrollView(this);
        bar.setHorizontalScrollBarEnabled(false);
        categoriesHost = row();
        bar.addView(categoriesHost);
        shell.addView(bar, margins(-1, dp(52), 8));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        entriesHost = column();
        entriesHost.setPadding(0, dp(2), 0, dp(20));
        scroll.addView(entriesHost);
        shell.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        renderCategories();
        renderEntries();
    }

    private void updateLastCommand() {
        if (lastCommand != null) {
            lastCommand.setText(lastCopied.isEmpty() ? "📋 복사한 명령어가 여기에 표시됩니다" : "📋 마지막 명령어 · 다시 복사하려면 터치\n" + lastCopied);
        }
    }

    private void renderCategories() {
        categoriesHost.removeAllViews();
        for (String name : CATEGORIES) {
            Button chip = button(name, name.equals(category) ? Color.rgb(27, 136, 101) : PANEL);
            chip.setTextSize(12);
            chip.setMinHeight(dp(40));
            chip.setOnClickListener(v -> {
                category = name;
                renderCategories();
                renderEntries();
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(40));
            params.rightMargin = dp(7);
            categoriesHost.addView(chip, params);
        }
    }

    private void renderEntries() {
        if (entriesHost == null) return;
        entriesHost.removeAllViews();
        String query = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int found = 0;
        for (Entry e : entries) {
            if (!category.equals("전체") && !e.category.equals(category)) continue;
            String haystack = (e.name + " " + e.description + " " + e.command).toLowerCase(Locale.ROOT);
            if (!haystack.contains(query)) continue;
            found++;
            LinearLayout card = column();
            card.setPadding(dp(15), dp(13), dp(15), dp(12));
            card.setBackground(rounded(PANEL, 15));
            TextView title = text(e.name, 16, FORE, true);
            card.addView(title);
            TextView sub = text(e.description, 12, MUTED, false);
            sub.setPadding(0, dp(4), 0, dp(7));
            card.addView(sub);
            TextView cmd = text(e.command, 12, ACCENT, false);
            cmd.setMaxLines(2);
            card.addView(cmd, margins(-1, -2, 10));
            Button copy = button("명령어 복사", Color.rgb(32, 113, 90));
            copy.setOnClickListener(v -> copy(e.command));
            card.setOnClickListener(v -> copy(e.command));
            card.addView(copy, new LinearLayout.LayoutParams(-1, dp(42)));
            entriesHost.addView(card, margins(-1, -2, 9));
        }
        if (found == 0) {
            TextView none = text("검색 결과가 없습니다.\n다른 이름으로 검색하거나 '명령어 만들기'를 사용하세요.", 14, MUTED, false);
            none.setPadding(dp(16), dp(20), dp(16), 0);
            entriesHost.addView(none);
        }
    }

    private void copy(String command) {
        try {
            ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cb == null) throw new IllegalStateException("클립보드 서비스를 찾을 수 없습니다");
            cb.setPrimaryClip(ClipData.newPlainText("마크 PE 명령어", command));
            lastCopied = command;
            getPreferences(MODE_PRIVATE).edit().putString("last_command", command).apply();
            updateLastCommand();
            Toast.makeText(this, "복사 완료! 마크 채팅창에 붙여넣으세요.", Toast.LENGTH_SHORT).show();
        } catch (RuntimeException e) {
            new AlertDialog.Builder(this).setTitle("복사할 명령어")
                .setMessage(command).setPositiveButton("확인", null).show();
        }
    }

    private void openMinecraft() {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
        if (intent == null) {
            Toast.makeText(this, "Minecraft 앱을 찾지 못했습니다. 직접 실행해 주세요.", Toast.LENGTH_LONG).show();
            return;
        }
        try { startActivity(intent); }
        catch (RuntimeException e) {
            Toast.makeText(this, "Minecraft 자동 실행 실패. 홈 화면에서 직접 열어주세요.", Toast.LENGTH_LONG).show();
        }
    }

    private EditText field(String hint, String value) {
        EditText f = new EditText(this);
        f.setSingleLine(true);
        f.setTextSize(16);
        f.setHint(hint);
        f.setText(value);
        f.setSelectAllOnFocus(true);
        return f;
    }

    private LinearLayout dialogForm() {
        LinearLayout v = column();
        v.setPadding(dp(21), dp(7), dp(21), dp(6));
        return v;
    }

    private void openBuilderMenu() {
        final String[] names = {"아이템 지급", "상태 효과", "좌표 순간이동", "손에 든 아이템 마법부여"};
        new AlertDialog.Builder(this).setTitle("명령어 만들기")
            .setItems(names, (dialog, i) -> {
                if (i == 0) showItemBuilder();
                else if (i == 1) showEffectBuilder();
                else if (i == 2) showTpBuilder();
                else showEnchantBuilder();
            }).setNegativeButton("취소", null).show();
    }

    private void showItemBuilder() {
        LinearLayout v = dialogForm();
        EditText name = field("아이템 영문 ID", "minecraft:diamond");
        EditText count = field("수량 1~64", "64");
        count.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        v.addView(name); v.addView(count);
        new AlertDialog.Builder(this).setTitle("아이템 지급")
            .setView(v).setPositiveButton("명령어 복사", (dialog, which) -> {
                String id = name.getText().toString().trim().toLowerCase(Locale.ROOT);
                int n = parseInt(count.getText().toString(), -1);
                if (!id.matches("(?:minecraft:)?[a-z0-9_]{1,64}") || n < 1 || n > 64) {
                    showInvalid("아이템 ID는 영문/숫자/밑줄만, 수량은 1~64 사이여야 합니다."); return;
                }
                copy("/give @s " + id + " " + n);
            }).setNegativeButton("취소", null).show();
    }

    private void showEffectBuilder() {
        final String[] effectIds = {"speed", "jump_boost", "strength", "resistance", "night_vision", "haste", "water_breathing", "invisibility"};
        final String[] labels = {"속도", "점프 강화", "힘", "저항", "야간 투시", "성급함", "수중 호흡", "투명화"};
        LinearLayout form = dialogForm();
        Spinner effect = new Spinner(this);
        effect.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        form.addView(effect);
        EditText seconds = field("지속 시간 (초)", "3600");
        seconds.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        EditText amplifier = field("강도 (0~4)", "1");
        amplifier.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        form.addView(seconds); form.addView(amplifier);
        new AlertDialog.Builder(this).setTitle("상태 효과")
            .setView(form).setPositiveButton("명령어 복사", (d, which) -> {
                int sec = parseInt(seconds.getText().toString(), -1);
                int amp = parseInt(amplifier.getText().toString(), -1);
                if (sec < 1 || sec > 99999 || amp < 0 || amp > 4) {
                    showInvalid("지속 시간 1~99999초, 강도 0~4로 입력해 주세요."); return;
                }
                copy("/effect @s " + effectIds[effect.getSelectedItemPosition()] + " " + sec + " " + amp + " true");
            }).setNegativeButton("취소", null).show();
    }

    private void showTpBuilder() {
        LinearLayout form = dialogForm();
        EditText x = field("X", "~");
        EditText y = field("Y", "~");
        EditText z = field("Z", "~");
        form.addView(x); form.addView(y); form.addView(z);
        new AlertDialog.Builder(this).setTitle("좌표 순간이동")
            .setView(form).setPositiveButton("명령어 복사", (d, which) -> {
                String xx = x.getText().toString().trim(), yy = y.getText().toString().trim(), zz = z.getText().toString().trim();
                if (!validCoord(xx) || !validCoord(yy) || !validCoord(zz)) {
                    showInvalid("좌표는 숫자 또는 ~, ~10, ~-5 형식으로 입력하세요."); return;
                }
                copy("/tp @s " + xx + " " + yy + " " + zz);
            }).setNegativeButton("취소", null).show();
    }

    private boolean validCoord(String value) {
        return value.matches("(?:~(?:-?\\d+(?:\\.\\d+)?)?|-?\\d+(?:\\.\\d+)?)");
    }

    private void showEnchantBuilder() {
        final String[] names = {"날카로움 V", "효율 V", "보호 IV", "내구성 III", "수선 I", "행운 III", "약탈 III", "발화 II", "가벼운 착지 IV"};
        final String[] ids = {"sharpness 5", "efficiency 5", "protection 4", "unbreaking 3", "mending 1", "fortune 3", "looting 3", "fire_aspect 2", "feather_falling 4"};
        LinearLayout form = dialogForm();
        Spinner enchant = new Spinner(this);
        enchant.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        form.addView(enchant);
        TextView note = text("마인크래프트에서 강화 가능한 아이템을 손에 들고 명령어를 사용하세요.", 13, Color.DKGRAY, false);
        note.setPadding(0, dp(12), 0, 0);
        form.addView(note);
        new AlertDialog.Builder(this).setTitle("마법부여")
            .setView(form).setPositiveButton("명령어 복사", (d, which) ->
                copy("/enchant @s " + ids[enchant.getSelectedItemPosition()]))
            .setNegativeButton("취소", null).show();
    }

    private void showInvalid(String message) {
        new AlertDialog.Builder(this).setTitle("입력을 확인해 주세요").setMessage(message)
            .setPositiveButton("확인", null).show();
    }

    private int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value.trim()); }
        catch (NumberFormatException e) { return fallback; }
    }

    private void add(String c, String name, String desc, String cmd) {
        entries.add(new Entry(c, name, desc, cmd));
    }

    private void setupEntries() {
        add("아이템", "💎 다이아몬드 ×64", "건축·장비 제작", "/give @s diamond 64");
        add("아이템", "🟩 에메랄드 ×64", "주민 거래", "/give @s emerald 64");
        add("아이템", "⚔ 네더라이트 검", "강력한 무기 지급", "/give @s netherite_sword 1");
        add("아이템", "⛏ 네더라이트 곡괭이", "광질 도구 지급", "/give @s netherite_pickaxe 1");
        add("아이템", "🍎 마법 황금사과", "희귀 식량 4개", "/give @s enchanted_golden_apple 4");
        add("아이템", "📦 셜커 상자", "휴대용 보관 상자", "/give @s shulker_box 1");
        add("아이템", "🔥 네더라이트 주괴", "최종 장비 재료", "/give @s netherite_ingot 16");
        add("아이템", "🪄 명령 블록", "치트 사용 가능 월드용", "/give @s command_block 1");
        add("아이템", "🌟 경험치 병", "인챈트용 경험치", "/give @s experience_bottle 64");
        add("아이템", "🏮 횃불 ×64", "동굴 탐험", "/give @s torch 64");
        add("치트 능력", "⚡ 초고속 이동", "속도 효과 1시간", "/effect @s speed 3600 4 true");
        add("치트 능력", "🦘 슈퍼 점프", "점프 강화 1시간", "/effect @s jump_boost 3600 3 true");
        add("치트 능력", "🛡 강력 방어", "저항 효과 1시간", "/effect @s resistance 3600 4 true");
        add("치트 능력", "💪 강력한 공격", "힘 효과 1시간", "/effect @s strength 3600 4 true");
        add("치트 능력", "👁 야간 투시", "어둠에서도 잘 보이기", "/effect @s night_vision 3600 0 true");
        add("치트 능력", "💨 빠른 채굴", "성급함 효과", "/effect @s haste 3600 4 true");
        add("치트 능력", "🫧 수중 호흡", "물속 탐험", "/effect @s water_breathing 3600 0 true");
        add("치트 능력", "🫥 투명화", "모습 숨기기", "/effect @s invisibility 3600 0 true");
        add("치트 능력", "🧹 모든 효과 제거", "적용된 상태 효과 해제", "/effect @s clear");
        add("마법부여", "⚔ 날카로움 V", "검을 든 상태로 사용", "/enchant @s sharpness 5");
        add("마법부여", "⛏ 효율 V", "도구를 든 상태로 사용", "/enchant @s efficiency 5");
        add("마법부여", "🛡 보호 IV", "강화할 방어구를 손에 들기", "/enchant @s protection 4");
        add("마법부여", "🔧 내구성 III", "장비 내구도 소모 감소", "/enchant @s unbreaking 3");
        add("마법부여", "✨ 수선 I", "경험치로 장비 수리", "/enchant @s mending 1");
        add("마법부여", "🍀 행운 III", "도구에 행운 부여", "/enchant @s fortune 3");
        add("마법부여", "🔥 발화 II", "검에 불 효과", "/enchant @s fire_aspect 2");
        add("마법부여", "🪶 가벼운 착지 IV", "부츠에 낙하 피해 감소", "/enchant @s feather_falling 4");
        add("월드", "🌤 낮으로 변경", "시간을 아침으로 설정", "/time set day");
        add("월드", "🌙 밤으로 변경", "시간을 밤으로 설정", "/time set night");
        add("월드", "☀ 맑은 날씨", "비와 천둥 제거", "/weather clear");
        add("월드", "🌧 비 내리기", "월드에 비 내림", "/weather rain");
        add("월드", "⚡ 천둥", "천둥 번개 날씨", "/weather thunder");
        add("월드", "🎨 크리에이티브", "게임 모드 전환", "/gamemode creative @s");
        add("월드", "🌲 서바이벌", "게임 모드 전환", "/gamemode survival @s");
        add("월드", "📦 죽어도 아이템 유지", "월드 규칙 변경", "/gamerule keepinventory true");
        add("월드", "📦 아이템 유지 해제", "원래 규칙으로 변경", "/gamerule keepinventory false");
        add("몹", "🐄 소 소환", "플레이어 위치에 소환", "/summon cow ~ ~ ~");
        add("몹", "🐺 늑대 소환", "플레이어 위치에 소환", "/summon wolf ~ ~ ~");
        add("몹", "🐎 말 소환", "플레이어 위치에 소환", "/summon horse ~ ~ ~");
        add("몹", "🧟 좀비 소환", "플레이어 위치에 소환", "/summon zombie ~ ~ ~");
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Standard Android layout handles window resizing automatically.
    }
}
