import kr.toolbox.minemasterkr7.CommandFactory;
public final class CommandFactoryTest {
  static void eq(String actual, String expected) { if (!actual.equals(expected)) throw new AssertionError(actual + " != " + expected); }
  static void bad(Runnable r) { try { r.run(); throw new AssertionError("Expected invalid input"); } catch(IllegalArgumentException expected) { } }
  public static void main(String[] args) {
    eq(CommandFactory.give("minecraft:diamond", "64"), "/give @s minecraft:diamond 64");
    eq(CommandFactory.effect("speed", "120", "3"), "/effect @s speed 120 2 true");
    eq(CommandFactory.enchant("sharpness", "5", 5), "/enchant @s sharpness 5");
    eq(CommandFactory.tp("~", "64", "~-3.5"), "/tp @s ~ 64 ~-3.5");
    eq(CommandFactory.summon("cow"), "/summon cow ~ ~ ~");
    bad(()->CommandFactory.give("diamond;tp", "12"));
    bad(()->CommandFactory.give("diamond", "-5"));
    bad(()->CommandFactory.effect("speed", "2147483647", "2"));
    bad(()->CommandFactory.effect("speed", "60", "0"));
    bad(()->CommandFactory.enchant("sharpness", "6", 5));
    bad(()->CommandFactory.tp("~a", "0", "1"));
    bad(()->CommandFactory.summon("cow;kill"));
    System.out.println("CommandFactory: 12 assertions OK");
  }
}
