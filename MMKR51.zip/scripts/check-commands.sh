#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/mmkr_v7_test
javac -encoding UTF-8 -d /tmp/mmkr_v7_test app/src/main/java/kr/toolbox/minemasterkr7/CommandFactory.java scripts/CommandFactoryTest.java
java -cp /tmp/mmkr_v7_test CommandFactoryTest
